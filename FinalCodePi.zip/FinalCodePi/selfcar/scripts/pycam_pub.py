#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image as SensorImage
from time import sleep
from picamera import PiCamera
import numpy as np
from PIL import Image
##from cv_bridge import CvBridge, CvBridgeError
##import cv2

#cap = cv2.VideoCapture(0)
#print(cap.isOpened())
#bridge = CvBridge()
camera = PiCamera()
camera.resolution = (480, 240)
camera.framerate = 30

def talker():
	rospy.init_node('image', anonymous = False)
	pub = rospy.Publisher('/webcam', SensorImage, queue_size = 1)
	#rospy.init_node('image', anonymous = False)
	rate = rospy.Rate(10)
	while not rospy.is_shutdown():
		#ret, frame = cap.read()
		#cv2.imshow("Pub Image", frame)
		output = np.empty((240, 480, 3), dtype=np.uint8)
		camera.capture(output, 'rgb')
        	#camera.start_preview()
		#if not output:
			#break
			
		#msg = output
		im = Image.fromarray(output, "RGB")
		#im = output.convert('RGB')
		msg = SensorImage()
		msg.header.stamp = rospy.Time.now()
		msg.height = im.height
		msg.width = im.width
		msg.encoding = "rgb8"
		msg.is_bigendian = False
		msg.step = 3 * im.width
		msg.data = np.array(im).tobytes()
		pub.publish(msg)
		
		#if cv2.waitKey(1) & 0xFF == ord('q'):
			#break
		
		#if rospy.is_shutdown():
			#cap.release()
	
if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
	
	
