#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image as SensorImage
from std_msgs.msg import Header
from time import sleep
from picamera import PiCamera
import numpy as np
from PIL import Image
##from cv_bridge import CvBridge, CvBridgeError
##import cv2

#cap = cv2.VideoCapture(0)
#print(cap.isOpened())
#bridge = CvBridge()
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 30

def talker():
    rospy.init_node('image', anonymous = False)
    pub = rospy.Publisher('/webcam', SensorImage, queue_size = 1)
    #rospy.init_node('image', anonymous = False)
    rate = rospy.Rate(30)
    while not rospy.is_shutdown():
        #ret, frame = cap.read()
        
        msg = SensorImage()
        msg.header = Header()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = 'camera'
        msg.height = 480
        msg.width = 640
        msg.encoding = "rgb8"
        msg.is_bigendian = False
        msg.step = 3 * msg.width
        
        data = np.zeros((msg.height, msg.width, 3), dtype=np.uint8)
        camera.capture(data, 'rgb')
        #data = np.array(image)
        
        for i in range(msg.height):
            for j in range(msg.width):
                data[i,j,0] = i % 256 #red channel
                data[i,j,1] = (i // 3) % 256 #green channel
                data[i,j,2] = i // (3 * msg.width) #blue channel
                
                msg.data = data.tobytes()
                
                pub.publish(msg)
        

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass