#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image as SensorImage
from std_msgs.msg import MultiArrayLayout
#from time import sleep
import time
from picamera import PiCamera
from picamera.array import PiRGBArray
import numpy as np
from PIL import Image
##from cv_bridge import CvBridge, CvBridgeError
##import cv2

#cap = cv2.VideoCapture(0)
#print(cap.isOpened())
#bridge = CvBridge()
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 30

def talker():
    rospy.init_node('image', anonymous = False)
    pub = rospy.Publisher('/webcam', SensorImage, queue_size = 1)
    #rospy.init_node('image', anonymous = False)
    rate = rospy.Rate(30)
    while not rospy.is_shutdown():
        raw_capture=PiRGBArray(camera,size=(640,480))#create 3D RGB array raw_capture
        time.sleep(0.1) #time to get camera ready
        for frame in camera.capture_continuous(raw_capture, format='bgr', use_video_port=True):
            image = frame.array
            im = Image.fromarray(image, "RGB")
            msg = SensorImage()
            msg.header.stamp = rospy.Time.now()
            msg.height = im.height
            msg.width = im.width
            msg.encoding = "rgb8"
            msg.is_bigendian = False
            msg.step = 3 * im.width
            msg.data = np.array(im).tobytes()
            pub.publish(msg)
            raw_capture.truncate(0)

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
