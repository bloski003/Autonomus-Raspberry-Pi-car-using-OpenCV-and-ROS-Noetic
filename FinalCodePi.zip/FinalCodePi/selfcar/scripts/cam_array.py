#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image as SensorImage
from selfcar.msg import RGBArray
from time import sleep
from picamera import PiCamera
import numpy as np
from PIL import Image
##from cv_bridge import CvBridge, CvBridgeError
##import cv2

#cap = cv2.VideoCapture(0)
#print(cap.isOpened())
#bridge = CvBridge()
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 30

def talker():
	rospy.init_node('image', anonymous = False)
	pub = rospy.Publisher('/webcam', SensorImage, queue_size = 1)
	#rospy.init_node('image', anonymous = False)
	rate = rospy.Rate(10)
	while not rospy.is_shutdown():
		#ret, frame = cap.read()
		#cv2.imshow("Pub Image", frame)
		output = np.empty((480, 640, 3), dtype=np.uint8)
		camera.capture(output, 'rgb')
		msg = RGBArray()
		msg.r = output[:,:,0]
		msg.g = output[:,:,1]
		msg.b =output[:,:,2]
		pub.publish(msg)
		
		#if cv2.waitKey(1) & 0xFF == ord('q'):
			#break
		
		#if rospy.is_shutdown():
			#cap.release()
	
if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass